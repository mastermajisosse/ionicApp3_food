import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { FirstpPage } from './firstp';

@NgModule({
  declarations: [
    FirstpPage,
  ],
  imports: [
    IonicPageModule.forChild(FirstpPage),
  ],
})
export class FirstpPageModule {}
