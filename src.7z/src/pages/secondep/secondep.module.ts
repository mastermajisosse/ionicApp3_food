import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SecondepPage } from './secondep';

@NgModule({
  declarations: [
    SecondepPage,
  ],
  imports: [
    IonicPageModule.forChild(SecondepPage),
  ],
})
export class SecondepPageModule {}
